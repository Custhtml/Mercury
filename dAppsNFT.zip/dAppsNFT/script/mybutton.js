const myButton = document.getElementById('mybutton');

myButton.addEventListener('mouseover', () => {
    myButton.style.backgroundColor = 'red';
});

myButton.addEventListener('mouseout', () => {
    myButton.style.backgroundColor = 'yellow';
});

myButton.addEventListener('click', () => {
    myButton.style.backgroundColor = 'purple';
});
